export const getCachedPage = (route: string) => {};

export const setCachedPage = (route: string, page: string) => {};
